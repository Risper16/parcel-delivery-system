<html>
<title>
TPS TAKEAWAY ASSINGMEMT
</title>
<body BGCOLOR="CYAN" font="+3">
<h2><p>THANK YOU. WELCOME TO OUR SITE<p></h2>
<p>please fill in your details as instructed<p>
<form action="cyan2.php" method="post">
 REGISTRATION NUMBER:<br><input type="text" name="RegNo" pattern="[A-Za-z0-9]*" required="required"  required></br>
 FIRSTNAME:<br><input type="text" name="FName" pattern="[A-Za-z A-Za-z]*" required placeholder="Enter Text Only"> </br>
 LASTNAME:<br><input type="text" name="LName" pattern="[A-Za-z A-Za-z]*" required placeholder="Enter Text Only" required></br>
 GENDER:<br><input type="text" name="Gender" pattern="[A-Za-z A-Za-z]*" required placeholder="Enter Text Only" required></br>
 <input type="Submit" value="Submit" >
 </body>
</html>