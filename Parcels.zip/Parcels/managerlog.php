<?php
  require 'conn.php';
  if (isset ($_POST['officialname']) && isset ($_POST ['password']))
  {
    $name = $_POST['officialname'];
    $password = $_POST ['password'];
    $passhash = md5 ($password);
    
    if (!empty ($name) && !empty($password))
    {
      $query = "SELECT * FROM manager WHERE officialname= '$name' and password= '$passhash'";
      $queryrun = mysql_query($query);

      if (mysql_num_rows($queryrun) == 0)
      {
        echo 'Only the manager can access the requested page';
      }
      else if ( mysql_num_rows($queryrun) == 1 )
    {
                        session_start();
			$member = mysql_fetch_assoc($queryrun);

  			$_SESSION['OFFICIALNAME'] = $member['officialname'];
                        session_write_close();
			header("location: managerhome.php");
			exit();
    }
    } else {echo 'All field are required';}
  }
?>
 <br>
<h2><u>Manager Login Section.</u> <br><br></h2>

 <form action="manager.php" method="POST">

 Username: <input type="text" size=30 name="officialname" pattern="[A-Za-z A-Za-z]*" required placeholder="" required ><br><br>

 Password: <input type="password" size=30 name="password" ><br><br>
 
 <input type="submit" value="log in">
 
 </form>
