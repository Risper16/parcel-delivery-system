<script>

<!--datepicker -->

<link href="css/datepicker/ui.datepicker.css" type="text/css" rel="stylesheet"/>

<script type="text/javascript" src="js/datepicker/ui.datepicker.js"></script>
<!--datepicker -->
<script type="text/javascript" charset="utf-8">
jQuery(function($)
{
$(".date").datepicker();
});
</script>

<form method="POST">
     <div class="textleft">Birth Day:</div>
		<div class="textright"><input name="month" type="text" class="date"></div>
		<div class="input-container">
</form>